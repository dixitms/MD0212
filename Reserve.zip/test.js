var fromDate = new Date("2015-09-30");
var toDate = fromDate; //new Date(fromDate);
//toDate.setDate(fromDate.getDate() + 1);
var endDate = new Date("2015-10-05");

function BookingRecord(date){
    this.bookedFrom = new Date(date);
    this.bookedTo = new Date(date);
    
//    return this;
}

//console.log(fromDate);
//fromDate.setMonth(fromDate.getMonth() + 1);
//console.log(fromDate);
var records = [];
while (fromDate <= endDate) {
  var bookingRecord = new BookingRecord(fromDate);
  

  //  if (ctx.instance.resourceType === "Port")
  //    bookingRecord.portId = ctx.instance.resourceId;
  //  else if (ctx.instance.resourceType === "Bridge")
  //    bookingRecord.bridgeId = ctx.instance.resourceId;

//  bookingRecord.bookedFrom = fromDate;
//  bookingRecord.bookedTo = fromDate;
  records.push(JSON.stringify(bookingRecord));

//  console.log("created record ", bookingRecord);

  fromDate.setDate(fromDate.getDate() + 1);
  }

console.log("created records ", records);
//if edit record - get all records stored with prev ID and modify
//if cancel - delete -remov
