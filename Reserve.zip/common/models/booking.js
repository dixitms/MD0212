var loopback = require('loopback');
var port = loopback.findModel('Port');

module.exports = function(Booking) {

  var response = {};

  getAssignedPorts = function(projectID, cb) {
    var query = {
      where: {
        projectId: projectID
      },
      fields: {
        portId: true
      }
    };

    port.find(query, function(err, data) {
      if (err) throw err;
      response.assignedPorts = data;
      //cb(null, data);
    });
  }

  getBookedPorts = function(projectID, resourceType, startDate, endDate) {

    var query = {
      where: {
        and: [{
          projectId: projectID,
          resourceType: resourceType
        }, {
          or: [{
            bookedFrom: {
              between: [startDate, endDate]
            }
          }, {
            bookedTo: {
              between: [startDate, endDate]
            }
          }]
        }]
      },
      fields: {
        portId: true
      }
    };

    Booking.find(query, function(err, data) {
      if (err) throw err;
      //cb(null, data)
      response.bookedPorts = data;
      getAssignedPorts(projectID);
    });
  }

  Booking.available = function(projectId, resourceType, startDate, endDate, cb) {
    getBookedPorts(projectId, resourceType, startDate, endDate);

    //using time out as altenative to callback
    //TODO - implement callbacks properly
    setTimeout(function() {
      console.log("response.bookedPorts : ", response.bookedPorts);
      console.log("rresponse.assignedPorts : ", response.assignedPorts);
      response.bookedPorts.forEach(function(port) {
        console.log("checking port : " + port.portId)
        var index = response.assignedPorts.indexOf(port);
        if (index > -1) {
          console.log("removing port : " + port.portId)
          response.assignedPort.splice(index, 1);
        }
      });
      cb(null, response);
    }, 1000);
  }

  Booking.remoteMethod(
    'available', {
      http: {
        path: '/availabe',
        verb: 'get'
      },
      accepts: [{
        arg: 'projectId',
        type: 'string'
      }, {
        arg: 'resourceType',
        type: 'string'
      }, {
        arg: 'startDate',
        type: 'date'
      }, {
        arg: 'endDate',
        type: 'date'
      }],
      returns: {
        arg: 'available',
        type: 'object'
      }
    }
  );

};
