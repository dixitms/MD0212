module.exports = function(AppUser) {

};
