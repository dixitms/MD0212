module.exports = function(Bridge) {

};
