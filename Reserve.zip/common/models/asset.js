module.exports = function(Asset) {

};
