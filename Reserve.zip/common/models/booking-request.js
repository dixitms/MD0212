"use strict";

var loopback = require('loopback');

module.exports = function(BookingRequest) {

  //  var booking = loopback.findModel('Booking');

  function cehckIfPreviousRecords(ctx, bookingModel, requestId) {
    var bookingDate = new Date().toISOString();
    var query = {
      where: {
        bookedFrom: {
          gte: bookingDate
        },
        requestId: requestId.toString()
      }
    }
    console.log(" query ", query);
    bookingModel.find(query, function(err, records) {
      if (err) {
        console.log(err);
        throw err;
      }
      var recordsToPurge = [];
      records.forEach(function(record) {
        recordsToPurge.push(record.bookingId);
      });
      ctx.bookingRecordsToPurge = recordsToPurge;
      console.log("No of Reords to delete - ", ctx.bookingRecordsToPurge.length);
      console.log("Reords to delete - ", ctx.bookingRecordsToPurge);
      deletePreviuosRecords(bookingModel, ctx.bookingRecordsToPurge);
    });

  };

  function deletePreviuosRecords(bookingModel, bookingRecordsToPurge) {
    //get the records from database where bookingFrom date is greater than today
    //insert records in the database
    bookingRecordsToPurge.forEach(function(record) {
      bookingModel.destroyById(record,
        function(err, data) {
          if (err) {
            console.log(err);
            throw err;
          }
          console.log("deleted record from database - ", data);
        })
    });
  };

  BookingRequest.observe('before save', function(ctx, next) {

    //for each update, check if there are already booking records associated with this request.
    //All furture bookings associated with the request should be cleared from the database
    //before inserting new booking records.

    var booking = loopback.findModel('Booking');

    if (ctx.instance) {
      console.log('Calling', ctx.Model.modelName, ctx.instance.id);

      //check if this is a new request
      var requestId = ctx.instance.id;
      console.log(requestId);
      if (requestId)
        cehckIfPreviousRecords(ctx, booking, requestId);
    } else {
      console.log("data - ", ctx.data, "where - ", ctx.where);
      var requestId = ctx.where.requestId;
      console.log(requestId);
      if (requestId) {
        cehckIfPreviousRecords(ctx, booking, requestId);
      }
    }

    next();
  });

  BookingRequest.observe('after save', function(ctx, next) {

    function BaseRecord(bookedFromDate, bookedToDate) {

      if (ctx.instance.resourceType === "Port")
        this.portId = ctx.instance.resourceId;
      else if (ctx.instance.resourceType === "Bridge")
        this.bridgeId = ctx.instance.resourceId;

      this.resourceType = ctx.instance.resourceType;
      this.projectId = ctx.instance.projectId;
      this.requestId = ctx.instance.id;
      this.userId = ctx.instance.userId;


      //console.log("bookingDate input - ", bookingDate)
      this.bookedFrom = new Date(bookedFromDate);
      this.bookedTo = new Date(bookedToDate);

      return this;

    }

    if (ctx.instance) {
      console.log('Creating a new booking record', ctx.Model.modelName, ctx.instance.id);

      var booking = loopback.findModel('Booking');
      var records = [];
      var bookingDate = new Date(ctx.instance.bookedFrom);
      var bookingEndDate = new Date(ctx.instance.bookedTo);
      var skipDate = null;

      if (!ctx.isNewInstance) {
        //for update operations, the booking date would be from current date
        skipDate = new Date();
      }

      console.log("skipDate ***", skipDate);

      //check frequency
      var freq = ctx.instance.occuranceFrequency;
      switch (freq) {

        case "D":

          var index = 0;

          //create a booking record for each day
          while (bookingDate <= bookingEndDate) {

            if (skipDate !== null && bookingDate < skipDate) {
              bookingDate.setDate(bookingDate.getDate() + 1);
              continue;
            }

            records[index] = new BaseRecord(bookingDate, bookingDate);

            bookingDate.setDate(bookingDate.getDate() + 1);
            index++;

          }

          console.log("created records ", records);

          //insert records in the database
          booking.create(records, function(err, data) {
            if (err) {
              console.log(err);
              throw err;
            }
            console.log("added records in database - ", data);
          });

          break;

        case "W":
          //create a booking record for each week
          console.log("creating a booking record for each week");

          var index = 0;

          //create a booking record for each day
          while (bookingDate <= bookingEndDate) {

            if (skipDate !== null && bookingDate < skipDate) {
              bookingDate.setDate(bookingDate.getDate() + 7);
              continue;
            }

            records[index] = new BaseRecord(bookingDate, bookingDate);

            bookingDate.setDate(bookingDate.getDate() + 7);
            index++;
          }

          console.log("created records ", records);

          //set records in database
          booking.create(records, function(err, data) {
            if (err) {
              console.log(err);
              throw err;
            }
            console.log("added records in database - ", data);
          })

          break;
        case "F":
          //create a booking record for each fortnight
          console.log("creating a booking record for each fortnight");
          break;

        case "M":
          //create a booking record for each month
          console.log("creating a booking record for each month");

          var index = 0;

          //create a booking record for each day
          while (bookingDate <= bookingEndDate) {

            if (bookingDate < skipDate) {
              bookingDate.setMonth(startDate.getMonth() + index + 1);
              continue;
            }

            records[index] = new BaseRecord(bookingDate, bookingDate);
            var startDate = new Date(ctx.instance.bookedFrom);

            bookingDate.setMonth(startDate.getMonth() + index + 1);

            index++;
          }

          console.log("created records ", records);

          //set records in database
          booking.create(records, function(err, data) {
            if (err) {
              console.log(err);
              throw err;
            }
            console.log("added records in database - ", data);
          })

          break;
        default:
          //create a booking record as is
          console.log("creating a booking record as is");
      }
    }
    next();
  });

};
